

写在前头**

- 就如文档标题一样，这是一篇缺氧mod的开发教程，我会将我所理解的写在这里面，或者记录一些要点。

- 不会c#怎么办。当然，我也帮不了你因为我是学Python的，我也并未学过c#，但计算机语言是触类旁通的，不过也不要担心不会c#，你只需要知道这个代码在这里是什么意思就行了。

-  这篇文档是参照 https://github.com/Cairath/Oxygen-Not-Included-Modding/wiki/Introduction#your-first-mod 来写的

- 了解[Harmony](https://github.com/pardeike/Harmony) - 我们用于修补游戏方法的库。**在继续之前，****阅读和理解[Harmony 文档是绝对必要的。](https://harmony.pardeike.net/articles/patching.html)**
- 当然你们肯定也有更好的理解或者想法，这只是新手教程，给想写缺氧mod不知道怎么写，不知道从哪里开始提供一个思路，我们话不多说，步入正题。

# 一.初始

## 准备工作

### **下载 所需要的工具**

- **1.Visual Studio**      **勾选**   `.NET  桌面开发`  
- **下载地址**    https://visualstudio.microsoft.com/zh-hans/vs/

![01](..\缺氧新手模组制作教程\img\01.png)

在**单个组件**选项卡中，选择`.NET Framework 4.7.1 SDK`和.`NET Framework 4.7.1 目标包`   最后安装

![02](..\缺氧新手模组制作教程\img\02.png)



- **2.dnspy**    `反编译软件`
- **下载地址**   https://github.com/dnSpy/dnSpy



- **3.poedit**    `翻译软件`
- **下载地址**     https://poedit.net/

### 你的第一个模组

- 在这篇文档里，我们以 `氧气扩散器` 为实验对象，不过在对`氧气扩散器`动刀子前，我们先来个简单的
- **打开Visual Studio**  `创建新建项目`  选择 `类库(.NET Framework)`

![03](..\缺氧新手模组制作教程\img\03.png) 

- **框架选择**    `.NET Framework 4.7.1`

  ![04](..\缺氧新手模组制作教程\img\04.png)

- 单击下一步，然后为您的解决方案和项目选择名称。

#### **接下来就是引用程序集**

鼠标右键点击  `引用` >   `添加引用` >   `浏览` >  选择需要的程序集

- 找到   `...\SteamLibrary\steamapps\common\OxygenNotIncluded\OxygenNotIncluded_Data\Managed`  文件夹，添加以下文件：

  - `Assembly-CSharp.dll`
  - `Assembly-CSharp-firstpass.dll`
  - `0Harmony.dll`
  - `UnityEngine.dll`
  - `UnityEngine.UI.dll`
  - `UnityEngine.CoreModule.dll`

  - `UnityEngine.ImageConversionModule.dll`

#### **游戏日志**

游戏输出日志位于  `%USERPROFILE%\AppData\LocalLow\Klei\Oxygen Not Included\player.log`  这个文件将是你的朋友 - 在可访问的地方创建一个快捷方式。

#### **先看代码**

```c#
using HarmonyLib;


namespace Class1
{
	public class A
	{
        //这里有两种写法，还可以写成 [HarmonyPatch(typeof(Db),"Initialize")]
		[HarmonyPatch(typeof(Db))]
		[HarmonyPatch("Initialize")]
		public class A_A
		{
			public static void Prefix()
			{
				Debug.Log("我在Db.Initialize之前执行！");
			}

			public static void Postfix()
			{
				Debug.Log("我在Db.Initialize之后执行！");
			}
		}
	}
}
```

- `A_A`包含两个补丁（最后一次机会阅读 Harmony 文档！），它们将`Db.Initialize()`在原始代码之前和之后执行。您可以`Debug.Log()`在上述`游戏日志`文件中看到结果。
- 所有补丁都需要驻留在某个地方——通常它是一个更大的补丁类（在这种情况下是 `A `类），或者如果有逻辑需要划分它们，有时是一些较小的补丁。把补丁类放在哪里并不重要——但要保持整洁——稍后你必须在某个时候返回代码，所以不要做任何你将来会后悔的事情。 

#### mod.yaml 和 mod_info.yaml两个文件

**您需要创建以下这两个文件：**

第一个文件是 `mod.yaml`- 虽然模组没有它也能工作，但不要忽略它！

```yaml
title: "你的模组标题" 
description: "关于您的 Mod 的一些描述"
```

第二个文件是  `mod_info.yaml`- 这个文件是绝对必要的，没有它模组将无法工作

```yaml
supportedContent: ALL # 可能的选项: ALL, EXPANSION1_ID, VANILLA_ID.全部版本，all就是本体和DLC都能用
minimumSupportedBuild: 468097 # 将加载模组的最低游戏版本
version: 1.0.0 # 您的模组版本，显示在模组列表中。 为您和用户的信息
APIVersion: 2 # 需要指定 mod 使用 Harmony 2 并且已针对合并更改进行升级，现在基本都是2
```

#### 测试模组

一旦你编译了模组（记得将它编译为`Release`版本！），你必须将它移动到游戏模组目录。

你只想移动你**的**mod 的 .dll 而不是任何被引用的游戏文件。还包括上面提到的`mod_info.yaml`和。`mod.yaml`

里面有三个文件夹（如果 `%USERPROFILE%\Documents\Klei\OxygenNotIncluded\mods` 没有请新建）：

- `\Dev`- 这是开发中的模组应该去的地方。如果此文件夹中的模组崩溃，它不会在游戏重新启动时自动禁用。用这个来测试。
- `\Steam`- 您在 Steam 上订阅的模组会自动下载到那里。模组将在模组崩溃时自动禁用（任何模组）。
- `\Local`- 本地安装的模组，否则表现为`\Steam`.

![05](..\缺氧新手模组制作教程\img\05.png)

你的Dev文件结构应该是下面这个结构
`...\Klei\OxygenNotIncluded\mods\Dev\你的mod名字\`

- `xxxxx.dll`
- `mod.yaml`
- `mod_info.yaml`

想必你已经创建好了文件结构，但是里面只创建好了`mod_info.yaml `和  `mod.yaml`，但是没有这个  `xxxxx.ddl`  文件，接下来就开始教你如何得到`xxxxx.ddl` 这个文件

- 现在你需要打开**Visual Studio**，鼠标右键点击   `project` >   `生成` 

![06](..\缺氧新手模组制作教程\img\06.png)

- 可以看到生成成功，还能看到导出的文件夹位置  `...\ClassLibrary1\ClassLibrary1\bin\Debug`  在文件夹中找到文件，移动到Dev文件夹中
- 这就是3缺一的 .dll文件里，现在下面3个文件齐了

![08](..\缺氧新手模组制作教程\img\08.png)

- 让我们打开游戏吧！![09](..\缺氧新手模组制作教程\img\09.png)
- 勾选我们制作的mod后，重启游戏。进入游戏界面后打开`游戏日志`   是不是又不知道`游戏日志`在哪了，游戏日志的文件夹位置在这里 `%USERPROFILE%\AppData\LocalLow\Klei\Oxygen Not Included\player.log`   
- 又或者我们在游戏中直接找鼠标点击  `选项` >   `反馈` >   `浏览日志文件` >   `player.log` 

 ![10](..\缺氧新手模组制作教程\img\10.png)![11](..\缺氧新手模组制作教程\img\11.png)

- 打开   `player.log` 日志后，我们只需要确认一下是否成功运行，如果出现以下信息那么恭喜你，你的第一个mod制作成功，虽然它没有任何作用

  ![12](..\缺氧新手模组制作教程\img\12.png)

### 基础篇

#### 1.氧气扩散器

##### 找到官方翻译包

- 恭喜你完成了上面那些
- 接下来我们就开始对`氧气扩散器`动刀子了

**打开文件夹**   `..\OxygenNotIncluded\OxygenNotIncluded_Data\StreamingAssets\strings`  找到`strings_preinstalled_zh_klei.po ` 文件用 **poedit**打开它![13](..\缺氧新手模组制作教程\img\13.png)

- 键盘按下`Ctrl+F`进行查找，搜索`氧气扩散器`找到英文信息，复制它

![14](..\缺氧新手模组制作教程\img\14.png)

- 于是我们得到了`MINERALDEOXIDIZER`这便是`氧气扩散器`的名字。

##### **找到源代码**

**打开文件夹**   `..\OxygenNotIncluded\OxygenNotIncluded_Data\Managed`  找到`Assembly-CSharp.dll ` 文件用 **dnspy**打开它

 ![15](..\缺氧新手模组制作教程\img\15.png)

- 键盘按下`Ctrl+Shift+K`进行查找，搜索`MINERALDEOXIDIZER`找到`MineralDeoxidizerConfig`![16](..\缺氧新手模组制作教程\img\16.png)

##### **先看代码**

我将`MineralDeoxidizerConfig`当中的全部代码复制了过来方便解释

```c#
using System;
using TUNING;
using UnityEngine;

// Token: 0x02000372 RID: 882
public class MineralDeoxidizerConfig : IBuildingConfig
{
	// Token: 0x06000E15 RID: 3605 RVA: 0x000B751C File Offset: 0x000B571C
	public override BuildingDef CreateBuildingDef()
	{
		string id = "MineralDeoxidizer";
		int width = 1;
		int height = 2;
		string anim = "mineraldeoxidizer_kanim";
		int hitpoints = 30;
		float construction_time = 30f;
		float[] tier = BUILDINGS.CONSTRUCTION_MASS_KG.TIER3;
		string[] all_METALS = MATERIALS.ALL_METALS;
		float melting_point = 800f;
		BuildLocationRule build_location_rule = BuildLocationRule.OnFloor;
		EffectorValues tier2 = NOISE_POLLUTION.NOISY.TIER3;
		BuildingDef buildingDef = BuildingTemplates.CreateBuildingDef(id, width, height, anim, hitpoints, construction_time, tier, all_METALS, melting_point, build_location_rule, BUILDINGS.DECOR.PENALTY.TIER1, tier2, 0.2f);
		buildingDef.RequiresPowerInput = true;
		buildingDef.EnergyConsumptionWhenActive = 120f;//这是功耗
		buildingDef.ExhaustKilowattsWhenActive = 0.5f;
		buildingDef.SelfHeatKilowattsWhenActive = 1f;
		buildingDef.LogicInputPorts = LogicOperationalController.CreateSingleInputPortList(new CellOffset(0, 1));
		buildingDef.ViewMode = OverlayModes.Oxygen.ID;
		buildingDef.AudioCategory = "HollowMetal";
		buildingDef.Breakable = true;
		return buildingDef;
	}

	// Token: 0x06000E16 RID: 3606 RVA: 0x000B75BC File Offset: 0x000B57BC
	public override void ConfigureBuildingTemplate(GameObject go, Tag prefab_tag)
	{
		CellOffset cellOffset = new CellOffset(0, 1);
		Prioritizable.AddRef(go);
		Electrolyzer electrolyzer = go.AddOrGet<Electrolyzer>();
		electrolyzer.maxMass = 1.8f;
		electrolyzer.hasMeter = false;
		electrolyzer.emissionOffset = cellOffset;
		Storage storage = go.AddOrGet<Storage>();
		storage.capacityKg = 330f;
		storage.showInUI = true;
		ElementConverter elementConverter = go.AddOrGet<ElementConverter>();
		elementConverter.consumedElements = new ElementConverter.ConsumedElement[]
		{
			new ElementConverter.ConsumedElement(new Tag("Algae"), 0.55f, true)
		};
		elementConverter.outputElements = new ElementConverter.OutputElement[]
		{
			new ElementConverter.OutputElement(0.5f, SimHashes.Oxygen, 303.15f, false, false, (float)cellOffset.x, (float)cellOffset.y, 1f, byte.MaxValue, 0, true)
		};
		ManualDeliveryKG manualDeliveryKG = go.AddOrGet<ManualDeliveryKG>();
		manualDeliveryKG.SetStorage(storage);
		manualDeliveryKG.RequestedItemTag = new Tag("Algae");
		manualDeliveryKG.capacity = 330f;
		manualDeliveryKG.refillMass = 132f;
		manualDeliveryKG.choreTypeIDHash = Db.Get().ChoreTypes.FetchCritical.IdHash;
	}

	// Token: 0x06000E17 RID: 3607 RVA: 0x000029C0 File Offset: 0x00000BC0
	public override void DoPostConfigureComplete(GameObject go)
	{
		go.AddOrGet<LogicOperationalController>();
		go.AddOrGetDef<PoweredActiveController.Def>();
	}

	// Token: 0x0400093B RID: 2363
	public const string ID = "MineralDeoxidizer";

	// Token: 0x0400093C RID: 2364
	private const float ALGAE_BURN_RATE = 0.55f;

	// Token: 0x0400093D RID: 2365
	private const float ALGAE_STORAGE = 330f;

	// Token: 0x0400093E RID: 2366
	private const float OXYGEN_GENERATION_RATE = 0.5f;

	// Token: 0x0400093F RID: 2367
	private const float OXYGEN_TEMPERATURE = 303.15f;
}

```

- 我们首先它的结构就如下面这一样

```c#
//A就相当于上面的 MineralDeoxidizerConfig ，B就是 IBuildingConfig
public class A : B
{
    //A_a()就相当于上面的 CreateBuildingDef()
    public override BuildingDef A_a()
    { }
    //A_b(GameObject go, Tag prefab_tag)就是 ConfigureBuildingTemplate(GameObject go, Tag prefab_tag)
    public override void A_b(GameObject go, Tag prefab_tag)
    { }
    //这个就不用我介绍了吧，看氧气扩散器的源代码能看出来的
    public override void A_c(GameObject go)
    { }
}
```

- 知道结构就开始打补丁，相信你**harmony**文档有认真看吧

- 比如我们想修改`氧气扩散器`的功耗，自己可以在源代码里找找，找到一个`buildingDef.EnergyConsumptionWhenActive = 120f;`激活时的能量消耗 = 120f，就是说它的功耗启动时是消耗120瓦的，它的位置相对上面的结构来说是在`A_a()`里面的

- `[HarmonyPatch(typeof(A),"A_a")]`定位的固定格式

- `buildingDef.EnergyConsumptionWhenActive = 120f;`可以看到`EnergyConsumptionWhenActive = 120f`前面是有一个`buildingDef`的，它里面装了`EnergyConsumptionWhenActive = 120f`。于是套用固定格式`ref string __result`这个`string`就是`BuildingDef`，我们得到了`Postfix(ref BuildingDef __result)`

  ```c#
  //现在就开始定位，A里面的A_a
  [HarmonyPatch(typeof(A))]
  [HarmonyPatch("A_a")]
  //另一种写法 [HarmonyPatch(typeof(A),"A_a")] 它们的效果都是一样的
  public class A
  {
      public static void Postfix(ref BuildingDef __result)
      {
          //__result.现在就相当于buildingDef了
  	    __result.EnergyConsumptionWhenActive = 10f;//120改成10
          //__result.xxxxxxx = xxx;
          //__result.xxxxxxx = xxx;
      }
  }
  
  ```

  - 源代码
  - 有些源代码里没有但我们可以添加，还记得`ref BuildingDef __result`在**Visual Studio**中按住`Ctrl`然后然后去点击它，就能看到`BuildingDef`里都有哪些组件
  - 于是照葫芦画瓢，你能不能让`氧气过滤器`不会过热或者在水里也能工作。我在`BuildingDef`里找到了`Overheatable = true;`你们翻译一下就知道是什么意思了，这是过热他是等于`true`我们要的是不会过热，于是改成`false`

  ```c#
  using HarmonyLib;
  
  namespace Class1
  {
      //现在就开始定位，A里面的A_a,就是MineralDeoxidizerConfig里面的CreateBuildingDef
      [HarmonyPatch(typeof(MineralDeoxidizerConfig))]
      [HarmonyPatch("CreateBuildingDef")]
      //另一种写法 [HarmonyPatch(typeof(MineralDeoxidizerConfig),"CreateBuildingDef")] 它们的效果都是一	样的
      public class A
      {
          public static void Postfix(ref BuildingDef __result)
          {
              //__result.现在就相当于buildingDef了
              __result.EnergyConsumptionWhenActive = 10f;//10瓦
              __result.Overheatable = false；//不会过热
          }
      }
  }
  ```

  ![17](..\缺氧新手模组制作教程\img\17.png)

- 于是按前面教的一样生成，最后进入游戏，可以看到变成`10w`了

 ![18](..\缺氧新手模组制作教程\img\18.png)

当然，这个教程并未完成在后面我会继续更新的